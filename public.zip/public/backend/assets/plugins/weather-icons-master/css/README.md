# Weather Icons
*Version 1.3 - November 30th, 2014*

If you want to just include the CSS itself, just reference this file. Make sure you have the `font` folder that holds all the font files a level above the CSS folder. If you want to change it, you'll have to edit it in the source.